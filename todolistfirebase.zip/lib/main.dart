import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:mytodoapp/pages/home.dart';
/*
apiKey = google-service.json [api_key]
appId = google-service.json [mobilesdk_app_id]
messagingSenderId = google-service.json [project_number]
projectId = google-service.json [project_id]
*/
 // FLUTTER CLEAN

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: 'AIzaSyBqHZnbPva2ij2lyUOYztoyjp1eIwzUfyQ',
        appId: '1:1085039931641:android:689ec95fb759508826b228',
        messagingSenderId: 'todoapp-6388e',
        projectId: 'todoapp-6388e',
        storageBucket: 'todoapp-6388e.firebasestorage.app',
      )
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: Home(),
    );
  }
}




