import 'package:flutter/material.dart';
import 'package:hive_ce/hive.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final _myBox = Hive.box("MY_BOX");
  final _textController = TextEditingController();
  List todos = [];
  @override
  void initState() {

    // TODO: implement initState
    todos = _myBox.get("TODO_LIST") ?? [];
    super.initState();
  }

  // open new dialog box
  void openNewTodo() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add task"),
        content: TextField(
          controller: _textController,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _textController.clear();
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              addTodo();
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  // add new todo
  void addTodo() {
    String todo = _textController.text;
    setState(() {
      todos.add(todo);
      _textController.clear();
    });
    saveToDatabase();
  }

  // delete todo
  void deleteTodo(index) {
    setState(() {
      todos.removeAt(index);
    });
    saveToDatabase();
  }

  // save to database
  void saveToDatabase() {
    _myBox.put("TODO_LIST", todos);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: openNewTodo,
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: todos.length,
        itemBuilder: (context, index) {
          final todo = todos[index];
          return ListTile(
            title: Text(todo),
            trailing: IconButton(
              onPressed: () => deleteTodo(index),
              icon: Icon(Icons.delete),
            ),
          );
        },
      ),
    );
  }
}
